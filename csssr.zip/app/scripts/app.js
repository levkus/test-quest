import $ from 'jquery';
import jsSlider from '../blocks/javascript-slider/javascript-slider';

jsSlider(
	$('#slider-container'),
	$('#pointer'),
	$('#pointer-ghost'),
	$('.javascript-slider__level-selector'),
	$('#pointer-value')
);
